package edu.uoc.pac4;

public interface Eater{
    void eat(Food food) throws DinosaurException;
}

