package edu.uoc.pac4;

public enum Gender {
    MALE,
    FEMALE;
}
